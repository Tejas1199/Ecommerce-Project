import React from 'react'
import Sidebar from '../pages/Sidebar'

const OrderList = () => {
    return (
        <div>
            OrderList</div>
    )
}

export default OrderList