import React from 'react'
import Sidebar from '../pages/Sidebar'

const ManageProduct = () => {
    return (
        <div>
            ManageProduct
            </div>
    )
}

export default ManageProduct