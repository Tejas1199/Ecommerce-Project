import React from 'react'
import Sidebar from '../pages/Sidebar'

const PlaceOrder = () => {
    return (
        <div>
            PlaceOrder</div>
    )
}

export default PlaceOrder