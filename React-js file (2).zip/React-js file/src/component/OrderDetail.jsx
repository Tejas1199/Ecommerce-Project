import React from 'react'
import Sidebar from '../pages/Sidebar'

const OrderDetail = () => {
    return (
        <div>
            OrderDetail</div>
    )
}

export default OrderDetail