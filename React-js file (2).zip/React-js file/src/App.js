import './App.css';
import Routes from './pages/Routes';

function App() {
  return (
    <div>
    <Routes />
    </div>
  );
}

export default App;
