import React from 'react'

function YourCart() {
  return (
    <div>YourCart</div>
  )
}

export default YourCart