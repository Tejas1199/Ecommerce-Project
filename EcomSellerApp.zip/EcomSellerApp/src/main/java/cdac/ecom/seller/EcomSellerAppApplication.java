package cdac.ecom.seller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomSellerAppApplication {
	public static void main(String[] args) {
		SpringApplication.run(EcomSellerAppApplication.class, args);
	}
}

