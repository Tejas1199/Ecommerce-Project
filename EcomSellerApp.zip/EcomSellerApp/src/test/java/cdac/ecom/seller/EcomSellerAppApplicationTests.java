package cdac.ecom.seller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomSellerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
